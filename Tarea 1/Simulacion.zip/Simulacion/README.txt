Analisis y Contorl de Sistemas Lineales

David Felipe Duarte Sánchez
Carlos Enrique Elizondo Alfaro

Profesor: Ing. Adolfo Chaves Jimenez

---------------------------------------------------------------

Variables utilizadas para generar los valores en la simulación


m = 5 kg
M = 10 kg
g = 9.81 m/s^2
l = 0.30 m